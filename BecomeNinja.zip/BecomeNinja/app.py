from flask import Flask, render_template, request, session, redirect, g
from helpers import apology, login_required, get_first_date, get_last_date, add_month, calc_pace, calc_min_sec, calc_to_sec
import sqlite3
import datetime
from datetime import date,timedelta
from dateutil.relativedelta import relativedelta

app = Flask(__name__)
app.secret_key = b'flask-test'


# Definite functions for connecting SQLite3
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect('MyRunAppDB.sqlite3')
    return g.db

def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def delete_details(prac_d_ids):
    db = get_db()
    for prac_d_id in prac_d_ids:
        # 練習詳細データ削除前に、[prac_d_id]に紐づく[prac_id]を取得
        prac_d_id = int(prac_d_id)
        cur = db.execute("SELECT prac_id FROM Prac_detail WHERE prac_d_id=:prac_d_id", {'prac_d_id':prac_d_id})
        prac_id = cur.fetchall()[0][0]
        # print('prac_id:', prac_id)

        # [prac_d_id]に対応する練習詳細データをPrac_detailテーブルから削除
        db.execute("DELETE FROM Prac_detail WHERE prac_d_id=:prac_d_id", {'prac_d_id':prac_d_id})

        # 削除後の[prac_id]に該当する全ての練習詳細データを取得
        cur = db.execute("SELECT prac_d_id From Prac_detail WHERE prac_id =:prac_id", {'prac_id':prac_id})
        detail_num = cur.fetchall()
        # print(detail_num)
        # print('len(detail_num):', len(detail_num))
        
        # 練習詳細データが0件の場合、該当する練習データをPracticeテーブルから削除
        if len(detail_num) == 0:
            db.execute("DELETE FROM Practice WHERE prac_id=:prac_id", {'prac_id':prac_id})
            # print('練習データNo.{}を削除しました！'.format(prac_id))
    db.commit()


@app.route("/login", methods=["GET"])
def login():
    # Forget any user_id
    session.clear()
    return render_template("login.html")


@app.route("/login", methods=["POST"])
def post_login():
    # Ensure username was submitted
    username = request.form.get("username")
    password = request.form.get("password")
    if not username:
        return apology("You should input Username!", 403)
    # Ensure password was submitted
    elif not password:
        return apology("You should input Password!", 403)
    
    # TODO: Query Database for username and password
    # task: ユーザーネームが存在するかどうか調べる
    db = get_db()
    cur = db.execute("SELECT user_name FROM User")
    users = cur.fetchall()
    users = [user[0] for user in users] # convert tuple-type into list-type
    if username not in users:
        return apology("This Username don't exist!", 403)

    # task: Ensure whether password is correct or not
    cur = db.execute("SELECT * FROM User WHERE user_name=:user_name", {'user_name':username})
    user_profile = (cur.fetchall())[0]
    u_password = user_profile[4]
    if u_password != password:
        return apology("Password don't match!", 403)

    # task: session["user_id"]にuser_idをセット。
    session["user_id"] = user_profile[0]
    session["user_name"] = user_profile[1]
    
    # redirect to index.html
    return redirect("/")

@app.route("/register", methods=["GET"])
def register():
    return render_template("register.html")


@app.route("/register", methods=["POST"])
def post_register():
    # TODO: acuire values from input form
    username = request.form.get('username')
    birth = request.form.get('birth')
    vdot = request.form.get('vdot')
    password = request.form.get('password')
    confirmation = request.form.get('confirmation')
    # print(username, birth, vdot, password, confirmation)    # for Debug

    # TODO: if input is invalid, return apology().
    if confirmation != password:
        return apology("Password don't correspond with Password(again)", 400)

    # TODO: register to Database
    # task: 全てのユーザーネームを取得する
    db = get_db()
    cur = db.execute("SELECT user_name FROM User")
    users = cur.fetchall()
    users = [user[0] for user in users] # convert tuple-type into list-type

    # task: ユーザーネームが重複してないかを調べる　→重複なしの場合、登録
    if username in users:
        return apology("This Username is already registerd!", 400)
    db.execute("insert into User(user_name,birth, vdot, password) values(:user_name, :birth, :vdot, :password)", {'user_name':username, 'birth':birth, 'vdot':vdot, 'password':password})
    db.commit()

    # task: 登録後、user_idをsession["user_id"]へ格納。
    cur = db.execute("select user_id, user_name from User where user_name=:user_name", {'user_name':username})
    u_prof = (cur.fetchall())[0]
    user_id = u_prof[0]
    user_name = u_prof[1]
    # print('user_id:', user_id)
    # print('user_name:', user_name)
    session["user_id"] = user_id
    session["user_name"] = user_name

    # redirect to index.html
    return redirect("/")


@app.route("/", methods=["GET"])
@app.route("/index", methods=["GET"])
@login_required
def index():
    # Prepare for Session and Variables
    user_id = session["user_id"]
    dist_dic = {"total":0, "month":0, "week":0}
    menu_datas = []
    all_practices = []

    # TODO: データベースから練習メニュー一覧を取得
    db = get_db()
    cur = db.execute("SELECT menu_id, menu_title, menu_description FROM Menu WHERE user_id=:user_id", {'user_id':user_id})
    menus = cur.fetchall()
    # print(my_menu) # for Debug

    # menu_datasに辞書型を追加　※辞書型：(1)上記で獲得したmenuデータ、(2)総距離、(3)総タイム、(4)平均ペース
    for menu in menus:
        menu = list(menu)
        menu_datas.append({"menu":menu, "t_distance":0, "t_time":0, "pace_m":0, "pace_s":0, "pace":0.00})
    # for Debug(Before UPDATES)
    # for data in menu_datas:
    #     print(data)

    # Query prac_details
    cur = db.execute("SELECT menu_id, m_distance, m_time FROM Prac_detail WHERE prac_id in(SELECT prac_id FROM Practice WHERE user_id=:user_id)",{'user_id':user_id})
    prac_details = cur.fetchall()
    # print(prac_details)

    # append prac_detail-Data to menu_datas
    for p_detail in prac_details:
        # print(p_detail)
        for data in menu_datas:
            # print(data)
            if p_detail[0] == data["menu"][0]:
                # print("match!", "menu_id:", data["menu"][0])
                data["t_distance"] += p_detail[1]
                data["t_time"] += p_detail[2]
    
    # Calculate pace of each menu_data
    for data in menu_datas:
        if data["t_time"] != 0:
            data["pace_m"] = (int)((data["t_time"] / data["t_distance"]) / 60)
            data["pace_s"] = (int)((data["t_time"] / data["t_distance"]) % 60)
            data["pace"] = round(data["pace_m"]+data["pace_s"]/100, 2)
            # print("{0:.2f}".format(data["pace"])) # for Debug
    # for Debug(After UPDATES)
    # for data in menu_datas:
    #     print(data)

    # TODO: Calcurate Distances
    cur = db.execute("SELECT prac_id, prac_date FROM Practice WHERE user_id=:user_id", {'user_id':user_id})
    practice_datas = cur.fetchall()
    # print(prac_datas)

    # TODO: get Date-data of today and 1-week-ago-day
    today = date.today()
    w_ago = today + timedelta(days=-6)
    first_day = get_first_date(today)
    # print(today, w_ago, first_day)

    for data in practice_datas:
        prac_id = data[0]
        prac_data = {"prac_id":prac_id, "date":data[1], "distance":0.0, "time":0.0, "pace":0.0}
        total_dist = 0
        total_time = 0
        # TODO: Get Date-data of Practice-day
        dt = datetime.datetime.strptime(data[1], '%Y-%m-%d')
        data_day = datetime.date(dt.year, dt.month, dt.day)
        # print(data_day)

        # TODO: Get data_day's total_distance
        cur = db.execute("SELECT m_distance, m_time FROM Prac_detail WHERE prac_id=:prac_id", {'prac_id':prac_id})
        details = cur.fetchall()
        # print(m_distances)
        for detail in details:
            total_dist += detail[0]
            total_time += detail[1]
        
        # TODO: Append prac_data to all_practices
        prac_data["distance"] = total_dist
        prac_data["time"] = calc_min_sec(total_time)
        prac_data["pace"] = calc_pace(total_dist, total_time)
        all_practices.append(prac_data)

        # TODO: Calculate Total Distance
        dist_dic["total"] += total_dist
        
        # TODO: Calculate Month Distance
        if  first_day <= data_day and data_day <= today:
            dist_dic["month"] += total_dist

        # TODO: Calculate Week Distance
        if w_ago <= data_day and data_day <= today:
            dist_dic["week"] += total_dist
    # print(dist_dic)
    # print(all_practices)
    # 逆順表示
    all_practices = all_practices[::-1]

    return render_template("index.html", menu_datas=menu_datas, dist_dic=dist_dic, all_practices=all_practices)


@app.route("/index", methods=["POST"])
@login_required
def post_index():
    session["prac_id"] = request.form.get('edit_id')
    # print("隠れフォームの値:", request.form.get('edit_id'))
    return redirect("/practice_edit")


@app.route("/practice", methods=["GET"])
@login_required
def practice():
    # TODO: データベースから練習メニュー一覧を取得
    user_id = session["user_id"]
    db = get_db()
    cur = db.execute("SELECT menu_id, menu_title FROM Menu WHERE user_id=:user_id", {'user_id':user_id})
    menus = cur.fetchall()
    # print(menus) # for Debug

    # TODO: Acquire Today's date
    today = date.today()
    # print(today) # for Debug
    return render_template("practice.html",menus=menus, today=today)


@app.route("/practice", methods=["POST"])
@login_required
def post_practice():
    # Prepare for  Session and Variable
    user_id = session["user_id"]
    practices = []

    # TODO: acuire values from input form
    p_date = request.form.get('p_date')
    menu_kinds = int(request.form.get('menu_kinds'))
    # print(p_date, menu_kinds) # for Debug

    # get values from Menu1's forms
    menu1 = request.form.get('menu1')
    distance1 = request.form.get('distance1')
    time1_m = request.form.get('time1_m')
    time1_s = request.form.get('time1_s')
    time1 = calc_to_sec(int(time1_m), int(time1_s))
    pace1_m = request.form.get('pace1_m')
    pace1_s = request.form.get('pace1_s')
    pace1 = calc_to_sec(int(pace1_m), int(pace1_s))
    # Append Menu1's Data to practices List
    practices.append({"menu_id": menu1,"distance":distance1, "time":time1, "pace":pace1})

    # TODO: check Practice Menu2
    if menu_kinds >= 2:
        # get values from Menu2's forms
        menu2 = request.form.get('select_menu2')
        distance2 = request.form.get('distance2')
        time2_m = request.form.get('time2_m')
        time2_s = request.form.get('time2_s')
        time2 = calc_to_sec(int(time2_m), int(time2_s))
        pace2_m = request.form.get('pace2_m')
        pace2_s = request.form.get('pace2_s')
        pace2 = calc_to_sec(int(pace2_m), int(pace2_s))
        # Append Menu2's Data to practices List
        practices.append({"menu_id": menu2,"distance":distance2, "time":time2, "pace":pace2})

        # TODO: check Practice Menu3
        if menu_kinds == 3:
            # get values from Menu3's forms
            menu3 = request.form.get('select_menu3')
            distance3 = request.form.get('distance3')
            time3_m = request.form.get('time3_m')
            time3_s = request.form.get('time3_s')
            time3 = calc_to_sec(int(time3_m), int(time3_s))
            pace3_m = request.form.get('pace3_m')
            pace3_s = request.form.get('pace3_s')
            pace3 = calc_to_sec(int(pace3_m), int(pace3_s))
            # Append Menu3's Data to practices List
            practices.append({"menu_id": menu3,"distance":distance3, "time":time3, "pace":pace3})
    # print(practices)

    # TODO: Insert Data into Practice-Table
    db = get_db()
    db.execute("INSERT INTO Practice(user_id, prac_date) values(:user_id, :prac_date)",
        {'user_id':user_id, 'prac_date':p_date})
    cur = db.execute("SELECT prac_id FROM Practice WHERE prac_id = last_insert_rowid()")
    prac_id = (cur.fetchall())[0][0]

    # TODO: Insert Data into Prac_detail-Table
    for item in practices:
        db.execute("INSERT into Prac_detail(prac_id, menu_id, m_distance, m_time, m_pace) values(:prac_id, :menu_id, :m_distance, :m_time, :m_pace)",
            {'prac_id':prac_id, 'menu_id':item["menu_id"], 'm_distance':item["distance"], 'm_time':item["time"], 'm_pace':item["pace"]})

    # TODO: commit DB and redirect to Index
    db.commit()
    return redirect("/")


@app.route("/practice_edit", methods=["GET"])
@login_required
def practice_edit():
    session["before_path"] = request.path
    all_datas = []
    prac_id = session["prac_id"]
    # print('prac_id:', prac_id)

    db = get_db()
    cur =  db.execute("SELECT prac_date FROM Practice WHERE prac_id=:prac_id", {'prac_id':prac_id})
    prac_date = cur.fetchall()[0][0]

    db = get_db()
    cur = db.execute("SELECT menu_id, m_distance, m_pace, m_time, prac_d_id FROM Prac_detail WHERE prac_id=:prac_id",
            {'prac_id':prac_id})
    p_details = cur.fetchall()
    # print('p_details:', p_details)

    # Append each value to all_datas
    for detail in p_details:
        cur = db.execute("SELECT menu_title FROM Menu WHERE menu_id=:menu_id", {'menu_id':detail[0]})
        menu_title = cur.fetchall()[0][0]
        time = calc_min_sec(detail[3])
        pace = calc_pace(detail[1], detail[3])
        all_datas.append({"prac_d_id":detail[4] ,"menu_title":menu_title, "distance":detail[1], "time":time,"pace":pace})
        # print({"prac_d_id":detail[4] ,"menu_title":menu_title, "distance":detail[1], "time":time,"pace":pace})
    return render_template("practice_edit.html", all_datas=all_datas, prac_date=prac_date)


@app.route("/practice_edit", methods=["POST"])
@login_required
def post_practice_edit():
    prac_date = request.form.get('p_date')
    prac_id = session["prac_id"]
    db = get_db()
    db.execute("UPDATE Practice SET prac_date=:prac_date WHERE prac_id=:prac_id",
        {'prac_date':prac_date, 'prac_id':prac_id})
    db.commit()
    return redirect("/")

@app.route("/detail", methods=["GET"])
@login_required
def detail():
    # Prepare for Session, Variable, and DB
    session["before_path"] = request.path
    all_datas = []
    user_id = session["user_id"]
    db = get_db()

     # Get all prac_id
    cur = db.execute("SELECT prac_id, prac_date FROM Practice WHERE user_id=:user_id", {'user_id':user_id})
    prac_datas = cur.fetchall()
    # print(prac_datas)

    # get datas of prac_detail records from prac_id 
    for data in prac_datas:
        # Get all Prac_Detail Records
        prac_id = data[0]
        # print('prac_id:',prac_id)

        cur = db.execute("SELECT menu_id, m_distance, m_pace, m_time, prac_d_id FROM Prac_detail WHERE prac_id=:prac_id",
                {'prac_id':prac_id})
        p_details = cur.fetchall()
        # print('p_details:', p_details)

        # Append each value to all_datas
        for detail in p_details:
            cur = db.execute("SELECT menu_title FROM Menu WHERE menu_id=:menu_id", {'menu_id':detail[0]})
            menu_title = cur.fetchall()[0][0]
            time = calc_min_sec(detail[3])
            pace = calc_pace(detail[1], detail[3])
            all_datas.append({"prac_d_id":detail[4] ,"menu_title":menu_title, "date":data[1], "distance":detail[1], "time":time,"pace":pace})
            # print({"prac_d_id":detail[4] ,"menu_title":menu_title, "date":data[1], "distance":detail[1], "time":time,"pace":pace})
    # リストを逆順化
    all_datas = all_datas[::-1] 

    return render_template("detail.html", all_datas=all_datas)


@app.route("/to_detail_edit", methods=["POST"])
@login_required
def to_detail_edit():
    session["prac_d_id"] = request.form.get("edit_id")
    # print(request.form.get("edit_id"))
    return redirect("/detail_edit")


@app.route("/detail_edit", methods=["GET"])
@login_required
def detail_edit():
    user_id = session["user_id"]
    prac_d_id = session["prac_d_id"]
    data = {"menu_id":0, "distance":0.0, "time_m":0, "time_s":0,"pace_m":0, "pace_s":0}
    db = get_db()

    # Get Detail
    cur = db.execute("SELECT menu_id, m_distance, m_time, m_pace FROM Prac_detail WHERE prac_d_id=:prac_d_id",
        {'prac_d_id':prac_d_id})
    prac_data = cur.fetchall()[0]
    data["menu_id"] = prac_data[0]
    data["distance"] = prac_data[1]
    data["time_s"] = prac_data[2] % 60
    data["time_m"] = int((prac_data[2] - data["time_s"]) / 60)
    data["pace_s"] = prac_data[3] % 60
    data["pace_m"] = int((prac_data[3] - data["pace_s"]) / 60)

    # Get Menu
    cur = db.execute("SELECT menu_id, menu_title FROM Menu WHERE user_id=:user_id", {'user_id':user_id})
    menus = cur.fetchall()

    return render_template("detail_edit.html", menus=menus, data=data)


@app.route("/detail_edit", methods=["POST"])
@login_required
def post_detail_edit():
    # TODO: Database Upadate
    prac_d_id = session["prac_d_id"]

    # get values from Menu1's forms
    menu1 = request.form.get('menu1')
    distance1 = request.form.get('distance1')
    time1_m = request.form.get('time1_m')
    time1_s = request.form.get('time1_s')
    time1 = calc_to_sec(int(time1_m), int(time1_s))
    pace1_m = request.form.get('pace1_m')
    pace1_s = request.form.get('pace1_s')
    pace1 = calc_to_sec(int(pace1_m), int(pace1_s))
    # print('menu_id:' + str(menu1), 'distance_1:' + str(distance1), 'time1:' + str(time1), 'pace1:' + str(pace1))

    db = get_db()
    db.execute("UPDATE Prac_detail SET menu_id=:menu_id, m_distance=:m_distance, m_time=:m_time, m_pace=:m_pace WHERE prac_d_id=:prac_d_id", 
        {'menu_id':menu1, 'm_distance':distance1, 'm_time':time1,'m_pace':pace1, 'prac_d_id':prac_d_id})
    db.commit()

    # return redirect("/detail")
    return redirect(session["before_path"])


@app.route("/delete_detail_select1", methods=["POST"])
@login_required
def delete_detail_select1():
    # チェックボックスのvalue(prac_d_id)を取得
    prac_d_ids = request.form.getlist("select")
    delete_details(prac_d_ids)
    return redirect("/")


@app.route("/delete_detail_select2", methods=["POST"])
@login_required
def delete_detail_select2():
    # チェックボックスのvalue(prac_d_id)を取得
    prac_d_ids = request.form.getlist("select")
    delete_details(prac_d_ids)
    return redirect("/detail")


@app.route("/delete_detail_select3", methods=["POST"])
@login_required
def delete_detail_select3():
    # チェックボックスのvalue(prac_d_id)を取得
    prac_d_ids = request.form.getlist("select")
    delete_details(prac_d_ids)
    return redirect("/menu_edit")
        

@app.route("/menu", methods=["GET"])
@login_required
def menu():
    session.pop('menu_id', None)
    user_id = session["user_id"]
    # TODO: データベースから練習メニュー一覧を取得
    db = get_db()
    cur = db.execute("SELECT menu_title, menu_description, menu_id FROM Menu WHERE user_id=:user_id", {'user_id':user_id})
    my_menu = cur.fetchall()
    return render_template("/menu.html", my_menu=my_menu)


@app.route("/menu", methods=["POST"])
@login_required
def post_menu():
    # TODO: if input is invalid, return apology().
    user_id = session["user_id"]
    menu_title = request.form.get('menu_title')
    menu_description = request.form.get('menu_description')

    # TODO: Insert New Practice-Menu into Database
    db = get_db()
    db.execute("INSERT INTO Menu(user_id, menu_title, menu_description) values(:user_id, :menu_title, :menu_description)", {'user_id':user_id, 'menu_title':menu_title, 'menu_description':menu_description})
    db.commit()

    # redirect to menu.html
    return redirect("/menu")


@app.route("/menu_select", methods=["POST"])
@login_required
def menu_select():
    session["menu_id"] = request.form.get('edit_menu')
    return redirect("/menu_edit")


@app.route("/menu_edit", methods=["GET"])
@login_required
def menu_edit():
    d_count = 0
    menu_id = session["menu_id"]
    all_datas = []

    db = get_db()
    cur = db.execute("SELECT menu_title, menu_description, menu_id FROM Menu WHERE menu_id=:menu_id", {'menu_id':menu_id})
    menu_data = cur.fetchall()[0]
    
    # TODO: Get All prac_detail associated with practice-record
    cur = db.execute("SELECT prac_d_id, prac_id, m_distance, m_time, m_pace FROM Prac_detail WHERE menu_id=:menu_id", 
        {'menu_id':menu_id})
    menu_details = cur.fetchall()
    # print(menu_details)
    for detail in menu_details:
        cur = db.execute("SELECT prac_date FROM Practice WHERE prac_id=:prac_id", {'prac_id':detail[1]})
        prac_date = cur.fetchall()[0][0]
        time = calc_min_sec(detail[3])
        pace = calc_pace(detail[2], detail[3])
        # print({"prac_d_id":detail[0], "date":prac_date, "distance":detail[2], "time":time, "pace":pace})
        all_datas.append({"prac_d_id":detail[0], "date":prac_date, "distance":detail[2], "time":time, "pace":pace})
        d_count += 1

    # 新しいデータから表示
    all_datas = all_datas[::-1]

    return render_template("menu_edit.html", menu_data=menu_data, all_datas=all_datas, d_count=d_count)


@app.route("/menu_edit", methods=["POST"])
@login_required
def post_menu_edit():
    # TODO: Prepare for Session and Get Edit Menu Data
    menu_id = session["menu_id"]
    menu_title = request.form.get('menu_title')
    menu_description = request.form.get('menu_description')

    # TODO: Updatr Practice-Menu-Database
    db = get_db()
    db.execute("UPDATE Menu SET menu_title=:menu_title, menu_description=:menu_description WHERE menu_id=:menu_id", 
        {'menu_title':menu_title, 'menu_description':menu_description, 'menu_id':menu_id})
    db.commit( )

    # redirect to menu.html
    return redirect("/menu")


@app.route("/delete_menu_select", methods=["POST"])
@login_required
def delete_menu_select():
    menu_id = session["menu_id"]
    db = get_db()
    db.execute("DELETE FROM Menu WHERE menu_id=:menu_id", {'menu_id':menu_id})
    db.commit()
    return redirect("/deleted_menu")
        

@app.route("/deleted_menu", methods=["GET"])
@login_required
def deleted_menu():
    return render_template("deleted_menu.html")


@app.route("/record", methods=["GET"])
@login_required
def record():
    return render_template("record.html")
    

@app.route("/record_select", methods=["GET"])
@login_required
def record_select():
    # Prepare for Session, Variable, and DB
    user_id = session["user_id"]
    today = date.today()
    two_y_ago = today + relativedelta(years=-2)
    total_data = {"distance":0.0, "time":0, "pace":0}
    db = get_db()

    # Get all Menu_id and Menu_title
    cur = db.execute("SELECT menu_id, menu_title FROM Menu WHERE user_id=:user_id", {'user_id':user_id})
    menus = cur.fetchall()

    return render_template("record_select.html",b_start_day=two_y_ago, b_end_day=today, total_data=total_data,menus=menus)


@app.route("/record_select", methods=["POST"])
@login_required
def post_record_select():
    # Prepare for Session and variable
    user_id = session["user_id"]
    today = date.today()
    two_y_ago = today + relativedelta(years=-2)
    all_datas = []
    total_data = {"distance":0.0, "time":0, "pace":0}
    db = get_db()
    menu_id = request.form.get('menu_id')
    start_day = request.form.get('start_day')
    end_day = request.form.get('end_day')

    # Get all Menu_id and Menu_title
    cur = db.execute("SELECT menu_id, menu_title FROM Menu WHERE user_id=:user_id", {'user_id':user_id})
    menus = cur.fetchall()
    # Get all Practice Records 
    
    # Get all prac_id
    cur = db.execute("SELECT prac_id, prac_date FROM Practice WHERE user_id=:user_id and :start_day <= prac_date and prac_date <= :end_day", 
            {'user_id':user_id,'start_day':start_day, 'end_day':end_day})
    prac_datas = cur.fetchall()
    # print(prac_datas)
    if menu_id =="":
        m_title ="All Menus"
    else:
        cur = db.execute("SELECT menu_title FROM Menu WHERE menu_id=:menu_id", {'menu_id':menu_id})
        m_title = cur.fetchall()[0][0]

    # get datas of prac_detail records from prac_id 
    for data in prac_datas:
        # Get all Prac_Detail Records
        prac_id = data[0]
        if menu_id == "":
            cur = db.execute("SELECT menu_id, m_distance, m_pace, m_time FROM Prac_detail WHERE prac_id=:prac_id",
                {'prac_id':prac_id})
        else:
            cur = db.execute("SELECT menu_id, m_distance, m_pace, m_time FROM Prac_detail WHERE prac_id=:prac_id and menu_id=:menu_id",
                {'prac_id':prac_id, 'menu_id':menu_id})
        p_details = cur.fetchall()
        # print(p_details)

        # Append prac_detais-Records to all_datas
        for detail in p_details:
            # add detail's data to total_data
            total_data["distance"] += detail[1]
            total_data["time"] += detail[3]

            # Append each value to all_datas
            cur = db.execute("SELECT menu_title FROM Menu WHERE menu_id=:menu_id", {'menu_id':detail[0]})
            menu_title = cur.fetchall()[0][0]
            time = calc_min_sec(detail[3])
            pace = calc_pace(detail[1], detail[3])
            all_datas.append({"menu_title":menu_title, "date":data[1], "distance":detail[1], "time":time,"pace":pace})

    # calculate total_pace
    total_data["pace"] = calc_pace(total_data["distance"], total_data["time"])
    total_data["time"] = calc_min_sec(total_data["time"])
    all_datas = all_datas[::-1]

    return render_template("record_select.html", today=today,two_y_ago=two_y_ago, 
        total_data=total_data, all_datas=all_datas, menus=menus, m_title=m_title,
        b_start_day=start_day, b_end_day=end_day)


@app.route("/record_year", methods=["GET"])
@login_required
def record_year():
    # Prepare for Session, Variable, DB
    user_id = session["user_id"]
    month_datas = []
    db = get_db()

    # get each Date
    today = date.today()
    first_day = get_first_date(today + relativedelta(years=-1))
    last_day = get_last_date(first_day)

    for i in range(13):
        # Prepare for each Variable
        year = first_day.year
        month = first_day.month
        all_dic = {"distance":0.0, "time":0, "pace":0}
        month_dic = {"year":year, "month":month, "distance":0.0, "time":0, "pace":0}

        cur = db.execute("SELECT prac_id FROM Practice WHERE user_id=:user_id and :first_day <= prac_date and prac_date <= :last_day", 
            {'user_id':user_id,'first_day':first_day, 'last_day':last_day})
        prac_ids = cur.fetchall()
        for data in prac_ids:
            prac_id = data[0]
            cur = db.execute("SELECT m_distance, m_time FROM Prac_detail WHERE prac_id=:prac_id", {'prac_id':prac_id})
            prac_details = cur.fetchall()
            for detail in prac_details:
                month_dic["distance"] += detail[0]
                month_dic["time"] += detail[1]
                all_dic["distance"] += detail[0]
                all_dic["time"] += detail[1]
        
        # 1回以上ランニングをしていた月は、ペースを更新する
        if month_dic["time"] != 0:
            month_dic["pace"] = calc_pace(month_dic["distance"], month_dic["time"])
            month_dic["time"] = calc_min_sec(month_dic["time"])

        # Update first_day and last_day
        first_day = add_month(first_day)
        last_day = get_last_date(first_day)
        # Append month_dic to month_datas
        month_datas.append(month_dic)
    if all_dic["time"] != 0:
        all_dic["pace"] = calc_pace(all_dic["distance"], all_dic["time"])
        all_dic["time"] = calc_min_sec(all_dic["time"] )
    
    # 逆順表示
    month_datas = month_datas[::-1]

    return render_template("record_year.html", month_datas=month_datas, all_dic=all_dic)


@app.route("/profile", methods=["GET"])
@login_required
def profile():
    # TODO: Get User-Information from Database based on session[user_id]
    user_id = session["user_id"]
    db = get_db()
    cur = db.execute("select * from User where user_id=:user_id", {'user_id':user_id})
    user_profile = (cur.fetchall())[0]
    username = user_profile[1]
    birth = user_profile[2]
    vdot = user_profile[3]
    password = user_profile[4]
    confirmation = user_profile[4]

    return render_template("profile.html", username=username, birth=birth, vdot=vdot, 
        password=password, confirmation=confirmation)


@app.route("/profile", methods=["POST"])
@login_required
def post_profile():
    user_id = session["user_id"]

    # TODO: acuire values from input form
    birth = request.form.get('birth')   # SQLiteを使う段階でdate型に変換
    vdot = request.form.get('vdot')
    password = request.form.get('password')
    confirmation = request.form.get('confirmation')
    # print(birth, vdot, password, confirmation)    # for Debug

    # TODO: if input is invalid, return apology().
    if confirmation != password:
        return apology("Password don't correspond with Password(again)", 400)
    
    # TODO: Database Upadate
    db = get_db()
    db.execute("UPDATE User SET birth=:birth, vdot=:vdot, password=:password WHERE user_id=:user_id", {'birth':birth, 'vdot':vdot, 'password':password,'user_id':user_id})
    db.commit()

    # redirect to index.html
    return redirect("/")


@app.route("/logout")
def logout():
    # Forget any user_id
    session.clear()
    # Redirect user to login form
    return redirect("/login")


# テストコード
if __name__ == "__main__":
    app.debug = True
    app.run(host='localhost')
    # CS50-IDEで起動する場合　→application.pyに変更。デバッグコードを非表示