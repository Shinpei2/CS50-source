from flask import Flask, render_template, request, session, redirect, g
from helpers import apology, login_required, get_first_date, get_last_date, add_month, calc_pace, calc_min_sec, calc_to_sec, calc_mmss_to_sec, calc_mmss_dic
import sqlite3
import datetime
from datetime import date,timedelta
from dateutil.relativedelta import relativedelta

app = Flask(__name__)
app.secret_key = b'flask-test'


# Definite functions for connecting SQLite3
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect('BecomeNinja2.db')
    return g.db

def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def get_run_data(prac_id):
    db = get_db()
    cur = db.execute("SELECT distance, time, pace, heart_rate FROM RunData WHERE prac_id=:prac_id",
        {'prac_id':prac_id})
    run_data = cur.fetchall()[0]
    close_db()
    return run_data

def get_prac_data(prac_id):
    db = get_db()
    cur = db.execute("SELECT prac_date, goal, contents, condition_before, condition_after, register_flag FROM Practice WHERE prac_id=:prac_id",
        {'prac_id':prac_id})
    prac_data = cur.fetchall()[0]
    practice = {'prac_id':prac_id, 'prac_date':prac_data[0], 'goal':prac_data[1], 'contents':prac_data[2], 'condition1':prac_data[3], 
        'condition2':prac_data[4],'register_flag':prac_data[5],  'distance':0.0, 'time':0.0, 'pace':0.0, 'heart_rate':0}

    if prac_data[5] == 1:
        cur = db.execute("SELECT distance, time, pace, heart_rate FROM RunData WHERE prac_id=:prac_id",
            {'prac_id':prac_id})
        run_data = cur.fetchall()[0]
        close_db()
        # practice内の走行データを更新
        practice['distance'] = run_data[0]
        practice['time'] = run_data[1]
        practice['pace'] = run_data[2]
        practice['heart_rate'] = run_data[3]
    return practice


def delete_pratice(prac_id):
    db = get_db()
    # 走行データ→練習日誌の順で削除
    db.execute("DELETE FROM RunData WHERE prac_id=:prac_id", {'prac_id':prac_id})
    db.execute("DELETE FROM Practice WHERE prac_id=:prac_id", {'prac_id':prac_id})
    db.commit()
    close_db()
    return 0


@app.route("/login", methods=["GET"])
def login():
    # Forget any user_id
    session.clear()
    return render_template("login.html")


@app.route("/login", methods=["POST"])
def post_login():
    # Ensure username was submitted
    username = request.form.get("username")
    password = request.form.get("password")
    if not username:
        return apology("You should input Username!", 403)
    # Ensure password was submitted
    elif not password:
        return apology("You should input Password!", 403)
    
    # TODO: Query Database for username and password
    # task: ユーザーネームが存在するかどうか調べる
    db = get_db()
    cur = db.execute("SELECT user_name FROM User")
    users = cur.fetchall()
    users = [user[0] for user in users] # convert tuple-type into list-type
    if username not in users:
        return apology("This Username don't exist!", 403)

    # task: Ensure whether password is correct or not
    cur = db.execute("SELECT * FROM User WHERE user_name=:user_name", {'user_name':username})
    user_profile = (cur.fetchall())[0]
    u_password = user_profile[4]
    if u_password != password:
        return apology("Password don't match!", 403)

    # task: session["user_id"]にuser_idをセット。
    session["user_id"] = user_profile[0]
    session["user_name"] = user_profile[1]
    
    # redirect to index.html
    return redirect("/")


@app.route("/logout")
def logout():
    # Forget any user_id
    session.clear()
    # Redirect user to login form
    return redirect("/login")


@app.route("/register", methods=["GET"])
def register():
    return render_template("register.html")


@app.route("/register", methods=["POST"])
def post_register():
    # TODO: acuire values from input form
    username = request.form.get('username')
    birth = request.form.get('birth')
    vdot = request.form.get('vdot')
    password = request.form.get('password')
    confirmation = request.form.get('confirmation')
    # print(username, birth, vdot, password, confirmation)    # for Debug

    # TODO: if input is invalid, return apology().
    if confirmation != password:
        return apology("Password don't correspond with Password(again)", 400)

    # TODO: register to Database
    # task: 全てのユーザーネームを取得する
    db = get_db()
    cur = db.execute("SELECT user_name FROM User")
    users = cur.fetchall()
    users = [user[0] for user in users] # convert tuple-type into list-type

    # task: ユーザーネームが重複してないかを調べる　→重複なしの場合、登録
    if username in users:
        return apology("This Username is already registerd!", 400)
    db.execute("insert into User(user_name,birth, vdot, password) values(:user_name, :birth, :vdot, :password)", {'user_name':username, 'birth':birth, 'vdot':vdot, 'password':password})
    db.commit()

    # task: 登録後、user_idをsession["user_id"]へ格納。
    cur = db.execute("select user_id, user_name from User where user_name=:user_name", {'user_name':username})
    u_prof = (cur.fetchall())[0]
    user_id = u_prof[0]
    user_name = u_prof[1]
    # print('user_id:', user_id)
    # print('user_name:', user_name)
    session["user_id"] = user_id
    session["user_name"] = user_name

    # redirect to index.html
    return redirect("/")


@app.route("/", methods=["GET"])
@app.route("/index", methods=["GET"])
@login_required
def index():
    # セッションからuser_idを取得
    user_id = session["user_id"]
    session["before_url"] = request.url

    # DBへ接続
    db = get_db()

    # 1. 走行距離をDBから取得し、辞書run_distancesに格納
    dist_dic = {"all":0.0, "year":0.0, "this_month":0.0, "week":0.0}

    #  全練習の走行距離を取得
    cur = db.execute("SELECT prac_id, prac_date From Practice WHERE user_id=:user_id", {'user_id':user_id})
    prac_datas = cur.fetchall()
    # print(prac_datas)

    # 日付データを取得
    today = date.today()
    first_day = get_first_date(today)
    w_ago = today + timedelta(days=-6)
    year_ago = (today + relativedelta(years=-1))
    # print(today, first_day, w_ago, year_ago)

    # 全ての走行データを走査
    for data in prac_datas:
        prac_id = data[0]
        cur = db.execute("SELECT distance FROM RunData WHERE prac_id=:prac_id", {'prac_id':prac_id})
        distance = cur.fetchall()[0][0]

        # prac_dateをtimedelta型に変換
        dt = datetime.datetime.strptime(data[1], '%Y-%m-%d')
        data_day = datetime.date(dt.year, dt.month, dt.day)

        # 合計走行距離への追加
        dist_dic["all"] += distance

        # 年間走行距離への追加
        if year_ago <= data_day and data_day <= today:
            dist_dic["year"] += distance 
        
        # 月間走行距離への追加
        if first_day <= data_day and data_day <= today:
            dist_dic["this_month"] += distance

        # 直近7日間の走行距離への追加
        if w_ago <= data_day and data_day <= today:
            dist_dic["week"] += distance
    
    # 2. 直近1か月分の練習データ・走行データを取得して、practicesに追加
    practices = []
    month_ago = (today + relativedelta(months=-1))
    # 直近1か月分の練習データのprac_idを取得
    cur = db.execute("SELECT prac_id FROM Practice WHERE :month_ago <= prac_date and prac_date <= :today",
        {'prac_id':prac_id, 'month_ago':month_ago, 'today':today})
    prac_datas = cur.fetchall()
    
    # 練習データ1件ずつから走行データを取得して、practicesに追加
    for data in prac_datas:
        prac_all_data = get_prac_data(data[0])
        if prac_all_data["register_flag"] == 1:
            prac_all_data["register_flag"] = "有"
        else:
            prac_all_data["register_flag"] = "無"
        practices.append(prac_all_data)

    # print(practices)
    # print(dist_dic)
    return render_template("index.html", dist_dic=dist_dic, practices=practices)


@app.route("/practice", methods=["GET"])
@login_required
def practice():
    # 今日の日付を取得
    today = date.today()
    return render_template("practice.html", today=today)


@app.route("/practice", methods=["POST"])
@login_required
def post_practice():
    # セッションからuser_idを取得
    user_id = session["user_id"]

    # 1．フォームから練習データの値を取得
    p_date = request.form.get("p_date")
    p_goal = request.form.get("p_goal")
    comment = request.form.get("comment")
    condition1 = request.form.get("condition1")
    condition2 = request.form.get("condition2")
    register_flag = request.form.get("register_flag")
    if register_flag != "1":
        register_flag = 0
    # print(p_date, p_goal, comment, condition1, condition2, register_flag)

    if condition1 == "":
        condition1 = "0"
    if condition2 == "":
        condition2 = "0"

    # 2．Practiceテーブルに練習データを登録
    db = get_db()
    db.execute("INSERT INTO Practice(user_id, prac_date, goal, contents, condition_before, condition_after, register_flag) values(:user_id, :prac_date, :goal, :contents, :condition_before, :condition_after, :register_flag)",
        {'user_id':user_id, 'prac_date':p_date, 'goal':p_goal, 'contents':comment, 'condition_before':condition1, 'condition_after':condition2, 'register_flag':register_flag})

    # 直前に登録した練習データからprac_idを取得
    cur = db.execute("SELECT prac_id FROM Practice WHERE prac_id = last_insert_rowid()")
    prac_id = (cur.fetchall())[0][0]

    # 走行フラグがtrueの場合、走行データをDBへ登録
    if register_flag == "1":

        # フォームから走行データを取得
        distance = float(request.form.get("distance1"))
        time_m = float(request.form.get("time1_m"))
        time_s = float(request.form.get("time1_s"))
        time = calc_min_sec(time_m, time_s)
        pace = calc_pace(distance, calc_to_sec(time_m, time_s))
        heart_rate = request.form.get("heart_rate")
        # print(prac_id, distance, time, pace, heart_rate)

        # RunDataテーブルに走行データを登録
        db.execute("INSERT INTO RunData(prac_id, distance, time, pace, heart_rate) values(:prac_id, :distance, :time, :pace, :heart_rate)",
            {'prac_id':prac_id, 'distance':distance, 'time':time, 'pace':pace, 'heart_rate':heart_rate})

    # 走行フラグがFalseの場合は全ての値をデフォルト値で登録
    else:
        db.execute("INSERT INTO RunData(prac_id, distance, time, pace, heart_rate) values(:prac_id, :distance, :time, :pace, :heart_rate)",
            {'prac_id':prac_id, 'distance':0.0, 'time':0.0, 'pace':0.0, 'heart_rate':0})
    
    # DBコミット、トップへのリダイレクト
    db.commit()
    return redirect("/")



@app.route("/record", methods=["GET"])
@login_required
def record():
    return render_template("record.html")

@app.route("/record_all", methods=["GET"])
@login_required
def record_all():
    # セッションからuser_idを取得
    user_id = session["user_id"]
    session["before_url"] = request.url
    # 全練習データ格納用のリストを定義
    practices = []

    # 1. DBからユーザの全練習データを取得
    db = get_db()
    cur = db.execute("SELECT prac_id, prac_date, condition_before, condition_after,register_flag  FROM Practice WHERE user_id=:user_id", {'user_id':user_id})
    practice_datas = cur.fetchall()

    # 2. 全練習データをpracticesに格納
    for data in practice_datas:
        # 走行データ用の変数を用意
        distance = 0.0
        time = 0.0
        pace = 0.0
        heart_rate = 0
        # print(data)

        # 走行フラグ=Trueの場合、走行データを更新
        if data[4] == 1:
            data_flag = "有"
            # prac_idと一致する走行データをDBから取得
            run_data = get_run_data(data[0])
            # 走行データ更新処理
            distance = run_data[0]
            time = run_data[1]
            pace = run_data[2]
            heart_rate = run_data[3]
        else:
            data_flag = "無"
        
        # practicesに練習データをappend
        practices.append({'prac_id':data[0], 'prac_date':data[1], 'distance':distance, 'time':time, 'pace':pace, 'heart_rate':heart_rate,
            'condition_before':data[2], 'condition_after':data[3], 'data_flag':data_flag})
 
    # 5. テンプレートへ全練習データを渡す
    return render_template("record_all.html", practices=practices)


@app.route("/to_practice_edit", methods=["POST"])
@login_required
def to_practice_edit():
    # 隠しフォーム(name="select")のvalueをセッションに格納
    session["prac_id"] = request.form.get("edit_id")
    return redirect("/practice_edit")

@app.route("/practice_edit", methods=["GET"])
@login_required
def practice_edit():
    prac_id = session["prac_id"]
    # print(prac_id)
    practice = get_prac_data((int)(prac_id))
    # print(practice)
    time_sec = calc_mmss_to_sec(practice["time"])
    pace_sec = calc_mmss_to_sec(practice["pace"])
    time = calc_mmss_dic(time_sec)
    pace = calc_mmss_dic(pace_sec)
    # print(time, pace)
    
    return render_template("practice_edit.html", practice=practice, time=time, pace=pace)

@app.route("/practice_edit", methods=["POST"])
@login_required
def post_practice_edit():
    # sessionからprac_idを取得
    prac_id = session["prac_id"]

    # 1．フォームから練習データの値を取得
    p_date = request.form.get("p_date")
    p_goal = request.form.get("p_goal")
    comment = request.form.get("comment")
    condition1 = request.form.get("condition1")
    condition2 = request.form.get("condition2")
    register_flag = request.form.get("register_flag")
    if register_flag != "1":
        register_flag = 0
    # コンティションが未選択の場合、「0」に変換
    if condition1 == "":
        condition1 = "0"
    if condition2 == "":
        condition2 = "0"
    # print(p_date, p_goal, comment, condition1, condition2, register_flag)
    
    # 2. Practiceテーブルの更新
    db = get_db()
    db.execute("UPDATE Practice SET prac_date=:prac_date, goal=:goal, contents=:contents, condition_before=:condition_before, condition_after=:condition_after, register_flag=:register_flag WHERE prac_id=:prac_id",
        {'prac_date':p_date, 'prac_id':prac_id, 'goal':p_goal, 'contents':comment, 'condition_before':condition1, 'condition_after':condition2, 'register_flag':register_flag})

    # 3. 「走行フラグ=True」の場合、RunDataテーブルを更新
    if register_flag == "1":
        # 走行データを取得して登録
        distance = request.form.get('distance')
        # フォームから走行データを取得
        distance = float(request.form.get("distance1"))
        time_m = float(request.form.get("time1_m"))
        time_s = float(request.form.get("time1_s"))
        time = calc_min_sec(time_m, time_s)
        pace = calc_pace(distance, calc_to_sec(time_m, time_s))
        heart_rate = request.form.get("heart_rate")
        # print(prac_id, distance, time, pace, heart_rate)

        # 走行データの更新
        db.execute("UPDATE RunData SET prac_id=:prac_id, distance=:distance, time=:time, pace=:pace, heart_rate=:heart_rate WHERE prac_id=:prac_id",
            {'prac_id':prac_id, 'distance':distance, 'time':time, 'pace':pace, 'heart_rate':heart_rate})

    db.commit()
    return redirect(session["before_url"])
    # return redirect("/record_all")


@app.route("/record_delete", methods=["POST"])
@login_required
def record_delete():
    # 「CheckBox=True」の練習のprac_idを取得
    prac_ids = request.form.getlist("select")
    print(prac_ids)

    # prac_idに紐づく練習データを1件1件削除
    for prac_id in prac_ids:
        prac_id = (int)(prac_id)
        print(prac_id)
        delete_pratice(prac_id)

    return redirect("/record_all")


@app.route("/record_duration", methods=["GET"])
@login_required
def record_duration():
    # 合計値を格納するための辞書
    sum_data = {"dist":0.0, "time":0.0, "pace":0.0}

    # 日付を取得
    today = date.today()   # 今日
    two_y_ago = today + relativedelta(years=-2) # 今日から丁度2年前
    # print(today, two_y_ago)

    # 期間表示部分の日付
    sample_day = 'yyyy-mm-dd'

    return render_template("record_duration.html", sum_data=sum_data, start_day=two_y_ago, end_day=today, 
        select_start_day=sample_day, select_end_day=sample_day)


@app.route("/record_duration", methods=["POST"])
@login_required
def post_record_duration():
    # 1. セッションからuser_idを取得
    user_id = session["user_id"]

    # 2. 辞書・リストの定義
    total_time_sec = 0
    sum_data = {"dist":0.0, "time":0.0, "pace":0.0}    # 合計値を格納するための辞書
    practices = []  # 練習データを格納するためのリスト

    # 3. 開始日と終了日をフォームから取得 
    start_day = request.form.get('start_day')
    end_day = request.form.get('end_day')
    # print(start_day, end_day)

    # 4. 全練習データをpracticesに格納

    # 開始日～終了日までのユーザの練習データを取得
    db = get_db()
    cur = db.execute("SELECT prac_id, prac_date, register_flag FROM Practice WHERE user_id=:user_id and :start_day <= prac_date and prac_date <= :end_day",
        {'user_id':user_id, 'start_day':start_day, 'end_day':end_day})
    prac_datas = cur.fetchall()
    # print(prac_datas)
    
    # 練習データ1件ずつから、走行データを取得してpracticesにappend
    for data in prac_datas:
        # 走行フラグが「1」のデータのみを取得
        if data[2] == 1:
            # 走行データを取得
            run_data = get_run_data(data[0]) 
            # print(run_data)

            # 走行データを変数に格納
            distance = run_data[0]
            time = run_data[1]
            pace = run_data[2]
            heart_rate = run_data[3]
            # total_time_secを更新
            total_time_sec += (int)(time) * 60 + (int)((time - (int)(time)) * 100)
            # 取得した練習データから合計値を計算
            sum_data["dist"] += distance
            sum_data["time"] = calc_min_sec((int)(total_time_sec / 60), (total_time_sec % 60))
            sum_data["pace"] = calc_pace(sum_data["dist"], total_time_sec)

            # practicesに練習データをappend
            practices.append({'prac_date':data[1], 'distance':distance, 'time':time, 'pace':pace, 'heart_rate':heart_rate})
        else:
            pass

    return render_template("record_duration.html", start_day=start_day, end_day=end_day, sum_data=sum_data, 
        practices=practices, select_start_day=start_day, select_end_day=end_day)


@app.route("/recommend", methods=["GET"])
@login_required
def recommend():
    return render_template("recommend.html")


@app.route("/recommend_ai", methods=["GET"])
@login_required
def recommend_ai():
    return render_template("recommend_ai.html")


@app.route("/recommend_vdot", methods=["GET"])
@login_required
def recommend_vdot():
    return render_template("recommend_vdot.html")


@app.route("/profile", methods=["GET"])
@login_required
def profile():
    # TODO: Get User-Information from Database based on session[user_id]
    user_id = session["user_id"]
    db = get_db()
    cur = db.execute("select * from User where user_id=:user_id", {'user_id':user_id})
    user_profile = (cur.fetchall())[0]
    username = user_profile[1]
    birth = user_profile[2]
    vdot = user_profile[3]
    password = user_profile[4]
    confirmation = user_profile[4]

    return render_template("profile.html", username=username, birth=birth, vdot=vdot, 
        password=password, confirmation=confirmation)


@app.route("/profile", methods=["POST"])
@login_required
def post_profile():
    user_id = session["user_id"]

    # TODO: acuire values from input form
    birth = request.form.get('birth')   # SQLiteを使う段階でdate型に変換
    vdot = request.form.get('vdot')
    password = request.form.get('password')
    confirmation = request.form.get('confirmation')
    # print(birth, vdot, password, confirmation)    # for Debug

    # TODO: if input is invalid, return apology().
    if confirmation != password:
        return apology("Password don't correspond with Password(again)", 400)
    
    # TODO: Database Upadate
    db = get_db()
    db.execute("UPDATE User SET birth=:birth, vdot=:vdot, password=:password WHERE user_id=:user_id", {'birth':birth, 'vdot':vdot, 'password':password,'user_id':user_id})
    db.commit()

    # redirect to index.html
    return redirect("/")


# テストコード
if __name__ == "__main__":
    app.debug = True
    app.run(host='localhost')
    # CS50-IDEで起動する場合　→application.pyに変更。デバッグコードを非表示